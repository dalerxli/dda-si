% http://en.wikipedia.org/wiki/Sellmeier_equation

% The Sellmeier equation is an empirical relationship between refractive 
% index and wavelength  for a particular transparent medium. The equation 
% is used to determine the dispersion of light in the medium. It was first 
% proposed in 1871 by W. Sellmeier, and was a development of the work of 
% Augustin Cauchy on Cauchy's equation for modelling dispersion.

function m = n_Sellmeier(lambda,B1,B2,B3,C1,C2,C3)

% borosilicate crown glass (known as BK7) 	
% 1.03961212 	0.231792344 	1.01046945 	6.00069867e?3 	2.00179144e?2 	1.03560653e2
% 
% sapphire (for ordinary wave) 	
% 1.43134930 	0.65054713    5.3414021 	5.2799261e?3    1.42382647e?2   3.25017834e2
% 
% sapphire (for extraordinary wave) 	
% 1.5039759 	0.55069141    6.5927379 	5.48041129e?3 	1.47994281e?2   4.0289514e2
% 
% fused silica 	
% 0.696166300 0.407942600 	0.897479400 4.67914826e?3 	1.35120631e?2   97.9340025

lambdamu = lambda/1000;
m = sqrt(1 + B1*lambdamu.^2./(lambdamu.^2 - C1) + ...
             B2*lambdamu.^2./(lambdamu.^2 - C2) + ...
             B3*lambdamu.^2./(lambdamu.^2 - C3));