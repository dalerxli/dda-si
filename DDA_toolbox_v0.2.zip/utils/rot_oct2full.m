function r = rot_oct2full(r_oct)

r = [r_oct; 
     rot_phi(r_oct,pi/4);
     rot_phi(r_oct,pi/2);
     rot_phi(r_oct,3*pi/4);
     rot_phi(r_oct,pi);
     rot_phi(r_oct,5*pi/4);
     rot_phi(r_oct,3*pi/2);
     rot_phi(r_oct,7*pi/4)];
     
