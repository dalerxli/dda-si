% cartesian coordinate system
function [X, Y] = arcpts(startpt, angles)
% centred at (0,0)

X = [];
Y = [];

for alpha = angles
  xy = [cos(-alpha) -sin(-alpha); sin(-alpha) cos(-alpha)]*[startpt(1); startpt(2)];
  X = [X xy(1)];
  Y = [Y xy(2)];
end  
  