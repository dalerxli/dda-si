function r_quad = rot_oct2quad(r_oct)

r_quad = [r_oct; 
     rot_phi(r_oct,pi/4)];
     
