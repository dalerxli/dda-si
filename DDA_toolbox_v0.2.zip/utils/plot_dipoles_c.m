function h = plot_dipoles_c(positions,radii,fignum,quality,col)
% plot_dipoles:
% 3D plot of discrete dipole representation of particle
%
% Usage:
% plot_dipoles(positions,radii)
% plot_dipoles(positions,radii,fignum)
% plot_dipoles(positions,radii,fignum,quality)
% plot_dipoles(positions,radii,fignum,quality,col)
%
% positions are [X Y Z] columns for cartesian coordinates
% i.e. |x1 y1 z1|
%      |x2 y2 z2|
%      |:  :  : |
%      |xN yN zN|
%
% radii is the vector containing radii of the spheres
% fignum is the figure number
% quality is the number of points on perimeter of each circle (ie dipole)
% (default value = 60)
% col is the colour e.g. 'r' for red
%
% NB: requires viewing angle set, and hold on before the funtion call
% limitations: does not work property for high polar angles

if length(radii) == 1
  radii = radii * ones(1,length(positions(:,1)));
end  

if nargin <= 4
   col = 'b';
end

if nargin <= 3
   quality = 60;
end

if nargin <= 2
  h = figure;
else
  h = figure(fignum);
end
  
plot3(0,0,0,'w');

cphi = linspace(0,2*pi,quality+1);
[cx,cy] = pol2cart(cphi,1); % Unit circle centred on origin
cz = zeros(size(cx));

[az,el] = view;

R1 = calc_rotation_matrix([0 0 (360-az)*pi/180]);
R2 = calc_rotation_matrix([(el-90)*pi/180 0 0]);
R = R1*R2;

Rinv = R.';

positions2 = positions * R;

[positions3,sortindex] = sortrows(positions2,3);
radii3 = radii(sortindex);
colour = positions3(:,3);
colour = colour - min(colour);
colour = colour/max(colour);
colour = colour/2 + 0.5;

for n = length(radii):-1:1
   
   x = cx*radii3(n) + positions3(n,1);
   y = cy*radii3(n) + positions3(n,2);
   z = cz + positions3(n,3);
   
   xyz = [ x(:) y(:) z(:) ] * Rinv;
   
%   patch(xyz(:,1),xyz(:,2),xyz(:,3),[1 1 1]*colour(n));
   patch(xyz(:,1),xyz(:,2),xyz(:,3),col);
   
end

axis equal
axis off