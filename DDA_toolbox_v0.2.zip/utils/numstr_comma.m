function s = numstr_comma(num)

s = strrep(num2str(num),'.',',');