function Nmax = TO2Nmax(total_orders)
% from quadratic formula
Nmax = (-2+sqrt(4+4*total_orders))/2;