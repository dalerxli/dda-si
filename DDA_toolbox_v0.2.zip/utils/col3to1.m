% % input vector   [v1x 
% %                 v1y 
% %                 v1z
% %                  .
% %                  .
% %                  .
% %                 vNx
% %                 vNy
% %                 vNz] 
%                 
% % output   [v1x v1y v1z
% %            .   .   .
% %            .   .   .
% %            .   .   .
% %           vNx vNy vNz]
%           

function onecol = col3to1(threecol)  

[N,dummy] = size(threecol);

onecol = zeros(3*N,1);
ind = 3*(1:N);
onecol(ind-2) = threecol(:,1);
onecol(ind-1) = threecol(:,2);
onecol(ind) = threecol(:,3);