function r = rot_phi(r0,phi)

Rz = rot_z(phi);
r = (Rz*r0')';