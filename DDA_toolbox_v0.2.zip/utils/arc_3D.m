function [X,Y,Z] = arc_3D(axispt,r,theta,phi)
% axispt in Cartesian coordinates

[x,y,z] = rtp2xyz(r,theta,phi);

X = x + axispt(1);
Y = y + axispt(2);
Z = z + axispt(3);