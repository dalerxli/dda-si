function [nn,mm,cii] = nm_oct(n,m,Nmax);

nm = [];
for ii = 0:Nmax
  for jj = -Nmax:Nmax
    %[n+2*ii m+4*jj; n+2*ii+1 m+4*jj]
    ni1 = n+2*ii;
    ni2 = n+2*ii+1;
    mj = m+4*jj;

    if (abs(mj) <= Nmax)
      if (abs(mj) <= abs(ni1)) & (abs(ni1) <= Nmax)
        nm = [nm; ni1 mj];
      end
      if (abs(mj) <= abs(ni2)) & (abs(ni2) <= Nmax)
        nm = [nm; ni2 mj];
      end
    end
  end
end

nn = nm(:,1);
mm = nm(:,2);
cii = combined_index(nn,mm);

% nm = sort(nm);
% nn = nm(:,1);
% mm = nm(:,2);
% cii = combined_index(nn,mm);
% 
% cii = unique(cii);
% [nn, mm] = combined_index(cii); 
