function r = oct2full(r_oct)

r = [r_oct; 
     -r_oct(:,2)  r_oct(:,1) r_oct(:,3);
     -r_oct(:,1) -r_oct(:,2) r_oct(:,3);
      r_oct(:,2) -r_oct(:,1) r_oct(:,3)];
     
r = [r; r(:,1) r(:,2) -r(:,3)];     