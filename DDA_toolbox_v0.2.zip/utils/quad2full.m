function r = quad2full(r_quad)

r = [r_quad; 
     -r_quad(:,2)  r_quad(:,1) r_quad(:,3);
     -r_quad(:,1) -r_quad(:,2) r_quad(:,3);
      r_quad(:,2) -r_quad(:,1) r_quad(:,3)];
     
