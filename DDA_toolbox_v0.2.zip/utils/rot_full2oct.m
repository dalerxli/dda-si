function r_oct = rot_full2oct(r)

%[r_sp,theta,phi] = xyz2rtp(r(:,1),r(:,2),r(:,3));
%ind = find((phi>0) & (phi<=pi/4));
ind = find(atan2(r(:,2),r(:,1))>0 & atan2(r(:,2),r(:,1))<=pi/4);
r_oct = r(ind,:);