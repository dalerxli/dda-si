function threecol = col1to3(onecol)  

N = length(onecol)/3;
ind = 3*((1:N)-1);
threecol = [onecol(ind + 1) onecol(ind + 2) onecol(ind + 3)];