function r_rounded = round_coord(r,d)

r_rounded = round(r/d)*d;
