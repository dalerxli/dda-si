function Rz = rot_z(gamma)

Rz = [cos(gamma) sin(gamma) 0;
      -sin(gamma) cos(gamma) 0;
      0 0 1];