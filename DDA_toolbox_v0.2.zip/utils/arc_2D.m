function [X, Y] = arc_2D(axispt,r,angles)
% axispt in Cartesian coordinates

[x,y,z] = rtp2xyz(r,pi/2*ones(1,length(angles)),angles);

X = x + axispt(1);
Y = y + axispt(2);