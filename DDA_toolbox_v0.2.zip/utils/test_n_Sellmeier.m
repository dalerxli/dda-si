
% Borosilicate crown BK7
B1 = 1.03961212; 	
B2 = 0.231792344; 	
B3 = 1.01046945; 	
C1 = 6.00069867E-3; 	
C2 = 2.00179144E-2; 	
C3 = 1.03560653E2;

% Fused Silica
% B1 = 0.696166300;
% B2 = 0.407942600; 	
% B3 = 0.897479400; 	  	 	
% C1 = 4.67914826e-003; 	 	
% C2 = 1.35120631e-002; 	
% C3 = 97.9340025;

lambda_range = 200:10:1600;
m = n_Sellmeier(lambda_range,B1,B2,B3,C1,C2,C3);

figure(1)
plot(lambda_range,m)
xlim([200 1600])
xlabel('\lambda (nm)','FontSize',14)
ylabel('n','FontSize',14)
set(gca,'FontSize',14)
title('n_{BK7} using Sellmeier coefficients')