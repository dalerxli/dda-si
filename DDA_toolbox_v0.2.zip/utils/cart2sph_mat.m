function M = cart2sph_mat(theta, phi)
  
M = [sin(theta)*cos(phi) sin(theta)*sin(phi) cos(theta);
     cos(theta)*cos(phi) cos(theta)*sin(phi) -sin(theta);
     -sin(phi) cos(phi) 0];
