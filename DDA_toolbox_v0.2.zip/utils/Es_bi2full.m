function [Es_TE, Es_TM] = Es_bi2full(m,Es_TE_q,Es_TM_q)

phi = pi;
Es_TE = Es_TE_q;
Es_TM = Es_TM_q;

M = m_matrix(m,pi);
Es_TE = [Es_TE;
  (M(1,1)*real(Es_TE_q) + M(1,2)*imag(Es_TE_q)) + i*(M(2,1)*real(Es_TE_q) + M(2,2)*imag(Es_TE_q))];
Es_TM = [Es_TM;
  (M(1,1)*real(Es_TM_q) + M(1,2)*imag(Es_TM_q)) + i*(M(2,1)*real(Es_TM_q) + M(2,2)*imag(Es_TM_q))];
