function r = bi2full(r_bi)

r = [r_bi; -r_bi(:,1) -r_bi(:,2) r_bi(:,3)]; 
     
