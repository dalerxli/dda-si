function r = oct2quad(r_oct)

r = r_oct; 
     
r = [r; r(:,1) r(:,2) -r(:,3)];     