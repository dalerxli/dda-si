% generate shape files (coordinates) for approximate 1:4 oblate spheroids

clear all
r = []
n = 20;

for x = -2*n:2*n-1
  for y = -2*n:2*n-1
    for z = -n:n-1
      r = [r; [x+.5 y+.5 z+.5]];
    end
  end
end

for rad = 3:n
  ro = [];
  npts = 0;
  for j = 1:length(r)
    rs = r(j,1)^2 + r(j,2)^2;  
    if (rs/rad^2 + r(j,3)^2/(.25*rad)^2) <= 1
      ro = [ro; r(j,:)];
      npts = npts + 1;
    end
  end  
  dlmwrite(['oblate_sphere_a4b1_N' int2str(npts) '.txt'], ro)
  figure(1)
  clf
  plot3(ro(:,1),ro(:,2),ro(:,3),'o')
  axis equal
end



  