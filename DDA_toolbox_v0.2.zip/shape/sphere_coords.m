% generate shape files (coordinates) for approximate spheres

clear all
r = []
n = 5;

for x = -n:n
  for y = -n:n
    for z = -n:n
      r = [r; [x y z]];
      if (z < n) & (y < n) & (x < n)
        r = [r; [x+.5 y+.5 z+.5]];
      end  
    end
  end
end

for rad = 1:5
  rsphere = [];
  npts = 0;
  for j = 1:length(r)
    if sqrt(r(j,1)^2 + r(j,2)^2 + r(j,3)^2) <= rad
      rsphere = [rsphere; r(j,:)];
      npts = npts + 1;
    end
  end  
  dlmwrite(['rsphere_' int2str(npts) '.txt'], rsphere)
end

  