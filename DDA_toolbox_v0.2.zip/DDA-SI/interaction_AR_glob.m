% interaction_AR.m
function interaction_AR_glob(k1,k2,r,alph)
global AR

% AR is 3N x 3N matrix
% k1 = wave number in bottom medium (substrate)
% k2 = wave number in top medium (could be air/vacuum)
% r: N x 3 matrix, for x_j, y_j, z_j coordinates
% N: number of dipoles
% j = 1..N

% AR means A + R
% A is as per Eqn(6) plus the inverse polarizability dagonal in 
% Draine & Flatau, 
% Discrete-dipole approximation for scattering calculations
% pgs 1491-1499, Vol. 11, No. 4 (1994), J. Opt. Soc. Am. A 

% the Rjk component represents radiating and receiving dipole interactions
% via substrate surface reflection; refer to:
% Roland Schmehl, Brent M. Nebeker, and E. Dan Hirleman
% "Discrete-dipole approximation for scattering by features on surfaces 
% by means of a two-dimensional fast Fourier transform technique" 
% J. Opt. Soc. Am. A 14, 3026-3036 (1997) 

k0 = 2*pi;
N = length(r(:,1));
AR = single(zeros(3*N,3*N));
I = eye(3);

[S,nS] = precalc_Somm(r,k1,k2);

iS = 0; %dipole combination counter
% nS(iS) determines which set of precalculated Sommmerfeld integrals to use
tic
for jj=1:N
  sprintf('Interaction matrix, dipole %d of %d',jj,N)
  for kk=1:N
    iS = iS + 1; 
    Rjk = reflection_Rjk(k1,k2,r(jj,:),r(kk,:),S(nS(iS),:)); % Schmehl et al.
    if jj ~= kk % off-diagonal
      rk_to_rj = r(jj,:)-r(kk,:);
      rjk = norm(rk_to_rj); %sqrt(sum((r(jj,:)-r(kk,:)).^2))
      rjk_hat = (rk_to_rj)/rjk;
      rjkrjk = rjk_hat'*rjk_hat;
      
      Ajk = exp(i*k0*rjk)/rjk*(k0^2*(rjkrjk - I) + (i*k0*rjk-1)/rjk^2*(3*rjkrjk - I)); %Draine & Flatau     
      
      % beta, gamma see Schmehl's thesis (1.27)
      rjk_x = rk_to_rj(1)/rjk; 
      rjk_y = rk_to_rj(2)/rjk; 
      rjk_z = rk_to_rj(3)/rjk; 
      beta = (1 - (k0*rjk)^-2 + i*(k0*rjk)^-1);
      gamma = -(1 - 3*(k0*rjk)^-2 + i*3*(k0*rjk)^-1);
      Ajk_BG = -exp(i*k0*rjk)/rjk*k0^2*...
        [(beta + gamma*rjk_x^2) (gamma*rjk_x*rjk_y)    (gamma*rjk_x*rjk_z);
         (gamma*rjk_y*rjk_x)    (beta + gamma*rjk_y^2) (gamma*rjk_y*rjk_z);
         (gamma*rjk_z*rjk_x)    (gamma*rjk_z*rjk_y)    (beta + gamma*rjk_z^2)];

      AR((jj-1)*3+1:jj*3,(kk-1)*3+1:kk*3) = (Ajk + Rjk);
    else
      AR((jj-1)*3+1,(kk-1)*3+1) = 1/alph((jj-1)*3+1);
      AR((jj-1)*3+2,(kk-1)*3+2) = 1/alph((jj-1)*3+2);
      AR((jj-1)*3+3,(kk-1)*3+3) = 1/alph((jj-1)*3+3);
      AR((jj-1)*3+1:jj*3,(kk-1)*3+1:kk*3) = AR((jj-1)*3+1:jj*3,(kk-1)*3+1:kk*3) + Rjk;
    end
  end
end
interact = toc
