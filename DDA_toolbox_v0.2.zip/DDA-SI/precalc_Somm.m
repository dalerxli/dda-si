function [S,n] = precalc_Somm(r,k1,k2);
% r: dipole coordinates
% k1: wave number in substrate
% k2: wave number in upper medium, e.g., air, water etc.

global use_mex
[N,dummy] = size(r);
zr = zeros(N*N,2);

ix = 0
for j = 1:N
  sprintf('precalc zph rho. %d of %d',j,N)
  for k = 1:N
    ix = ix+1;
    r_j = r(j,:);
    r_k = r(k,:);
    zph = r_j(3)+r_k(3);
    rho = sqrt((r_j(1) - r_k(1))^2 + (r_j(2) - r_k(2))^2);

    % round to 4 decimal places
%     zph = round2(zph,.0001);
%     rho = round2(rho,.0001);

    zr(ix,:) = [zph rho];
  end
end
zr0 = zr;
[zr,m,n] = unique(zr,'rows');
[L,dummy] = size(zr);


S = zeros(L,4);

for j = 1:L
  sprintf('precalc S. %d of %d',j,L)
  if use_mex
  I = somm(real(k1),imag(k1),k2,zr(j,1),zr(j,2));
    IV_rho = I(1) + i*I(2);
    IV_z  = I(3) + i*I(4);
    IH_rho  = I(5) + i*I(6);
    IH_phi  = I(7) + i*I(8);
  else
    [IV_rho,IV_z,IH_rho,IH_phi] = evlua(zph,rho,k1,k2);
  end
  S(j,:) = [IV_rho IV_z IH_rho IH_phi];
end
