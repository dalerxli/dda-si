% /* hankel evaluates hankel function of the first kind,   */
% /* order zero, and its derivative for complex argument z */
% void hankel( complex double z, complex double *h0, complex double *h0p )
function [h0,h0p] = hankel0(z)
m = zeros(101,1);
init = 0;
a1 = zeros(25,1);
a2 = zeros(25,1);
a3 = zeros(25,1);
a4 = zeros(25,1);

GAMMA	= .5772156649;
C1 =	-.02457850915;
C2 =	.3674669052;
C3 =	.7978845608;
P10 =	.0703125;
P20 =	.1121520996;
Q10 =	.125;
Q20 =	.0732421875;
P11 =	.1171875;
P21 =	.1441955566;
Q11	= .375;
Q21 =	.1025390625;
POF =	.7853981635;

% /* initialization of constants */
if ~init 
  psi=-GAMMA;
  for j = 1:24
    a1(j) = -.25/j^2;
    a2(j) = 1/(j + 1.0);
    psi = psi + 1/j;
    a3(j) = psi + psi;
    a4(j) = (psi + psi + 1/(j + 1))/(j + 1);
  end

  for j = 1:101 
    tst=1.0;
    for k = 1:24 
      init = k;
      tst = tst*-j*a1(k); 

      if (tst*a3(k) < 1E-6) 
        break
      end
    end
    m(j) = init; 
  end

  init = 1; 
end % if

zms = z*conj(z);

ib = 0;
if (zms <= 16.81)
  if (zms > 16)
    ib = 1;
  end

  % /* series expansion */
  iz = floor(zms) + 1; 
  miz = m(iz); 
  j0 = 1; 
  j0p = j0;
  y0 = 0; 
  y0p = y0;
  zk = j0;
  zi = z^2; 

  for k = 1:miz 
    zk = zk * a1(k)*zi; 
    j0 = j0 + zk; 
    j0p = j0p + a2(k)*zk; 
    y0 = y0 + a3(k)*zk; 
    y0p = y0p + a4(k)*zk; 
  end

  j0p = j0p*-.5*z; 
  logz = log(.5*z); 
  y0 = (2*j0*logz - y0)/pi + C2; 
  y0p = (2/z + 2*j0p*logz + .5*y0p*z)/pi + C1*z; 
  h0 = j0 + i*y0; 
  h0p = j0p + i*y0p; 

  if(ib == 0)
    return;
  end

  y0 = h0; 
  y0p = h0p; 

end % if

% /* asymptotic expansion */
zi = 1/z; 
zi2 = zi^2; 
p0z = 1 + (P20*zi2 - P10)*zi2; 
p1z = 1 + (P11 - P21*zi2)*zi2; 
q0z = (Q20*zi2 - Q10)*zi; 
q1z = (Q11 - Q21*zi2)*zi; 
zk = exp(i*(z - POF))*sqrt(zi)*C3; 
h0 = zk*(p0z + i*q0z); 
h0p = i*zk*(p1z + i*q1z); 

if (ib == 0)
  return
end

zms = cos((sqrt(zms) - 4)*pi*10); 
h0 = .5*(y0*(1 + zms) + h0*(1 - zms)); 
h0p = .5*(y0p*(1 + zms) + h0p*(1 - zms)); 

return
