% Ag cube on Si substrate

clear all

global use_mex AR
check_shape = 1;

lambda = 632.8 % nm
sides = 400 % nm

gamma = 65/180*pi; % incident angle in radians
%gamma = 0;
k = 2*pi; % wave number
n1 = n_Si(lambda); % refractive index of Si substrate 

n2 = 1; 
n3 = n_Ag(lambda); % refractive index Ag cube 
k1 = k*n1; % for bottom medium, subtrate
k2 = k*n2;    % for top medium

N = 512; % number of dipoles
%N = 1000; % number of dipoles

theta = linspace(-pi/2,pi/2,180); % phase angle range
pts = length(theta);
phi_p = zeros(1,pts);
phi_s = pi/2*ones(1,pts);
det_r = 100;

r = dlmread(['../../shape/cube_' int2str(N) '.txt']);
m = n3*ones(N,1);
nl = nthroot(N,3);
r(:,3) = r(:,3) + nl/2;
d = sides/nl/lambda;
r = d*r;

if check_shape
  r_nm = r*lambda;
  figure(1)
  clf
  hold on
  plot3(r_nm(:,1),r_nm(:,2),r_nm(:,3),'o','MarkerSize',d*lambda*.59)
  axis([-sides/2 sides/2 -sides/2 sides/2 0 sides]*1.1)
  axis equal
  xlabel('x')
  ylabel('y')
  view(45,45);
  hold off
end

% incident plane wave
E0 = [1 0 0]; % E-field [x y z]
kvec = k*[0 -sin(gamma) -cos(gamma)]; % wave vector [x y z]
Ei = E_inc(E0, kvec, r); % incident field at dipoles

% reflected incident plane wave
[refl_TE,refl_TM] = Fresnel_coeff_n(n1,abs(gamma))

E0_r = refl_TE*[1 0 0]; % E-field [x y z]
kvec_r = k*[0 -sin(gamma) cos(gamma)]; % wave vector [x y z]
Ei_r = E_inc(E0_r, kvec_r, r); % reflected field at dipoles

alph = polarizability_CM(d,m,k); % polarizability of dipoles

% matrix for direct and reflected interactions
%AR = interaction_AR(k1,k2,r,alph); % non-global version, 2 copies of AR
interaction_AR_glob(k1,k2,r,alph); % formulate interaction matrix

P = qmr(AR, Ei + Ei_r); % solve dipole moments

% calculate scattered field as a function of angles
% parallel to incident plane
rE = [det_r*ones(1,pts)' theta' phi_p'];
Esca = E_sca_SI(k,r,P,rE(:,1),rE(:,2),rE(:,3),n1);
E = Esca;
Ip = k^2*(det_r.^2)'.*dot(E,E,2);

% perpendicular to incident plane
rE = [det_r*ones(1,pts)' theta' phi_s'];
Esca = E_sca_SI(k,r,P,rE(:,1),rE(:,2),rE(:,3),n1);
E = Esca;
Is = k^2*(det_r.^2)'.*dot(E,E,2);

%save(['data/I_PF_cube_N' int2str(N) '.mat'],'Ip','Is')

th = theta'*180/pi;
figure(2)
clf
semilogy(th,Is,'-',th,Ip,'--')
ylabel('I_{sca}')
xlabel('Scattering Angle')
xlim([-90 90])
ylim([1e-5 1])

h=legend('p','s')
set(h,'Location','SouthEast')
title(['N=' int2str(N)])
%print('-dpng',['data/PF_cube_N' int2str(N) '.png'])

