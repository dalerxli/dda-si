% single Ag sphere on BK7 glass

clear all

global use_mex

use_mex = 0;
step = 20; % lambda step (nm)

% Spherical particle
lambda_range = 200:step:600; % nm
diameter = 40 %nm
zgap = 0; % gap btw sphere and substrate (fraction of radius)

gamma_deg = 0;
gamma = gamma_deg/180*pi;
k = 2*pi; % wave number

%r0 = dlmread('../../shape/sphere_32.txt'); N = 32;
r0 = dlmread('../../shape/sphere_136.txt'); N = 136;
%r0 = dlmread('../../shape/sphere_280.txt'); N = 280;
%r0 = dlmread('../../shape/sphere_552.txt'); N = 552;
%r0 = dlmread('../../shape/sphere_912.txt'); N = 912;
%r0 = dlmread('../../shape/sphere_1472.txt'); N = 1472;

% BK7 glass, Sellmeier coefficients
B1 = 1.03961212; 	
B2 = 0.231792344; 	
B3 = 1.01046945; 	
C1 = 6.00069867E-3; 	
C2 = 2.00179144E-2; 	
C3 = 1.03560653E2;
nBK7 = n_Sellmeier(lambda_range,B1,B2,B3,C1,C2,C3);
nAg = n_Ag(lambda_range);

Q_abs = zeros(1,length(lambda_range));
Q_abs_fs = zeros(1,length(lambda_range));
Q_ext = zeros(1,length(lambda_range));
Q_ext_fs = zeros(1,length(lambda_range));
R_p = zeros(1,length(lambda_range));

% incident plane wave
E0 = [0 cos(gamma) sin(gamma)]; % E-field [x y z]
kvec = k*[0 sin(gamma) -cos(gamma)] % wave vector [x y z]

ix = 0;
for lambda = lambda_range
  ix = ix + 1;
  n1 = nBK7(ix);
  mu_r = 1;

  n2 = 1;
  n3 = nAg(ix); % refractive index of sphere
  k1 = k*n1;
  k2 = k*n2;    % for top medium

  n_r = n1/n2;
  m = n3*ones(N,1)/n2;
  a_eff = diameter/(2 * lambda); % effective radius in wavelengths
  d = (4/3*pi/N)^(1/3)*a_eff;
  r = d*r0;
  r(:,3) = r(:,3) + a_eff + zgap*a_eff;

  % incident plane wave
  Ei = E_inc(E0, kvec, r); % direct incident field at dipoles

  % plane wave reflected off substrate  
  [refl_TE,refl_TM] = Fresnel_coeff_n(n_r,abs(gamma))
  E0_r = refl_TM*[0 -cos(gamma) sin(gamma)]; % E-field [x y z]
  kvec_r = k*[0 sin(gamma) cos(gamma)]; % wave vector [x y z]
  Ei_r = E_inc(E0_r, kvec_r, r); % reflected incident field at dipoles

  alph = polarizability_LDR(d,m,kvec); % polarizability of dipoles
  % matrix for direct and reflected interactions
  AR = interaction_AR(k1,k2,r,alph);  
  P = gmres(AR, Ei+Ei_r); % solve dipole moments
  
  Q_abs(ix) = C_abs(k,E0,Ei+Ei_r,P,alph)/(pi*a_eff^2);
end

figure(1)
plot(lambda_range, Q_abs,lambda_range, Q_abs_fs,'--');
title(['gamma = ' num2str(gamma*180/pi) ', zgap = ' num2str(zgap) ', N = ' int2str(N)])
