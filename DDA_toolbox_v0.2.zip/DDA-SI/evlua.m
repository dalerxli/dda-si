function [erv,ezv,erh,eph] = evlua(zph,rho,k1,k2)
% radiating dipole, k
% receiving dipole, j
% zph = z_j + z_k
% rho = radial coordinate for cylindrical system
% k1 = wave number in slab medium
% k2 = wave number in top medium 

% int i, jump;
% static double del, slope, rmis;
% static complex double cp1, cp2, cp3, bk, delta, delta2, sum[6], ans[6];

conj_e = 1;
bk = 0;
%suminc = zeros(6,1);
answer = zeros(6,1);

tkmag = 100*abs(k1); 

del=zph;
if rho > del
  del = rho;
end
  
if zph >= 2*rho
  % bessel function form of sommerfeld integrals
  jh = 0;
  a = 0;
  del=1/del;

  if del > tkmag
    b = .1*(1 - i)*tkmag; %b=cmplx(.1*tkmag,-.1*tkmag);
    suminc = rom1(6,2,zph,rho,k1,k2,a,b,jh);
    a = b;
    b = del*(1 - i);
    answer = rom1(6,2,zph,rho,k1,k2,a,b,jh);
%     for i = 0; i < 6; i++ )
%     	sum[i] += ans[i];
%     end
    suminc = suminc + answer;
  else
    b = del*(1 - i);
    suminc = rom1(6,2,zph,rho,k1,k2,a,b,jh);
  end

  delta = .2*pi*del;
  answer = gshank(b,delta,answer,6,suminc,0,b,b,zph,rho,k1,k2,jh); % gshank(b,delta,ans,6,sum,0,b,b);
  answer(6) = answer(6)*k1; % ans[5] *= k1;

  if conj_e
    % conjugate since nec uses exp(+jwt)
    erv = conj(k1^2*answer(3)); % *erv=conj(ck1sq*ans[2]);
    ezv = conj(k1^2*(answer(2)+k2^2*answer(5))); % *ezv=conj(ck1sq*(ans[1]+ck2sq*ans[4]));
    erh = conj(k2^2*(answer(1)+answer(6))); % *erh=conj(ck2sq*(ans[0]+ans[5]));
    eph = -conj(k2^2*(answer(4)+answer(6))); % *eph=-conj(ck2sq*(ans[3]+ans[5]));
  else
    % unconjugated
    erv = k1^2*answer(3); % *erv=conj(ck1sq*ans[2]);
    ezv = k1^2*(answer(2)+k2^2*answer(5)); % *ezv=conj(ck1sq*(ans[1]+ck2sq*ans[4]));
    erh = k2^2*(answer(1)+answer(6)); % *erh=conj(ck2sq*(ans[0]+ans[5]));
    eph = -k2^2*(answer(4)+answer(6)); % *eph=-conj(ck2sq*(ans[3]+ans[5]));
  end

  return
% } /* if(zph >= 2.*rho) */
else
  % hankel function form of sommerfeld integrals
  jh=1;
  cp1 = .4*k2*i; % cp1=cmplx(0.0,.4*ck2);
  cp2 = .6*k2 - .2*k2*i; % cp2=cmplx(.6*ck2,-.2*ck2);
  cp3 = 1.02*k2 - .2*k2*i; % cp3=cmplx(1.02*ck2,-.2*ck2);
  a = cp1;
  b = cp2;
  suminc = rom1(6,2,zph,rho,k1,k2,a,b,jh);
  a = cp2;
  b = cp3;
  answer = rom1(6,2,zph,rho,k1,k2,a,b,jh);

  % for( i = 0; i < 6; i++ )
  % sum[i]=-(sum[i]+ans[i]);
  suminc = -(suminc + answer);

  % path from imaginary axis to -infinity 
  if (zph > .001*rho)
    slope = rho/zph;
  else
    slope = 1000;
  end

  del = .2*pi/del;
  delta = (-1 + slope*i)*del/sqrt(1 + slope^2);
  delta2 = -conj(delta);
  answer = gshank(cp1,delta,answer,6,suminc,0,bk,bk,zph,rho,k1,k2,jh); % gshank(cp1,delta,ans,6,sum,0,bk,bk);
  rmis = rho*(real(k1) - k2);

  jump = 0; %jump = FALSE;
  if (rmis >= 2*k2) && (rho >= 1E-10)
    if (zph >= 1E-10)
      bk = (-zph + rho*i)*(k1-cp3); % bk=cmplx(-zph,rho)*(ck1-cp3);
      rmis = -real(bk)/abs(imag(bk)); % rmis=-creal(bk)/fabs(cimag(bk));
      if(rmis > 4*rho/zph)
	      jump = 1; % jump = TRUE;
      end
    end

    if ~jump % if( ! jump )
      % integrate up between branch cuts, then to + infinity 
      cp1 = k1 - (.1 + .2*i); % cp1=ck1-(.1+.2fj); 
      cp2 = cp1 + .2;
      bk = del*i; % bk=cmplx(0.,del);
      suminc = gshank(cp1,bk,suminc,6,answer,0,bk,bk,zph,rho,k1,k2,jh); % gshank(cp1,bk,sum,6,ans,0,bk,bk);
      a = cp1;
      b = cp2;
      answer = rom1(6,1,zph,rho,k1,k2,a,b,jh);
%       for( i = 0; i < 6; i++ )
% 	      ans[i] -= sum[i];
      answer = answer - suminc;

      suminc = gshank(cp3,bk,suminc,6,answer,0,bk,bk,zph,rho,k1,k2,jh); % gshank(cp3,bk,sum,6,ans,0,bk,bk);
      answer = gshank(cp2,delta2,answer,6,suminc,0,bk,bk,zph,rho,k1,k2,jh); % gshank(cp2,delta2,ans,6,sum,0,bk,bk);
    end
    
    jump = 1; % jump = TRUE;

  % /* if( (rmis >= 2.*ck2) || (rho >= 1.e-10) ) */
  else
    jump = 0; % jump = FALSE;
  end
    
  if ~jump % ( ! jump )
  %%{
    % integrate below branch points, then to + infinity
%     for( i = 0; i < 6; i++ )
%       sum[i]=-ans[i];
    suminc = -answer;
    
    rmis = real(k1)*1.01; % rmis=creal(ck1)*1.01;
%     if( (ck2+1.) > rmis )
%       rmis=ck2+1.;
    if (k2+1) > rmis
      rmis = k2 + 1;
    end

    bk = rmis + .99*imag(k1)*i; % bk=cmplx(rmis,.99*cimag(ck1));
    delta = bk - cp3;
    delta = delta*del/abs(delta); % delta *= del/cabs(delta);
    answer = gshank(cp3,delta,answer,6,suminc,1,bk,delta2,zph,rho,k1,k2,jh); % gshank(cp3,delta,ans,6,sum,1,bk,delta2);

  end % /* if( ! jump ) */

  answer(6) = answer(6)*k1; % ans[5] *= ck1;

  if conj_e
    % conjugate since nec uses exp(+jwt)
    erv = conj(k1^2*answer(3)); % *erv=conj(ck1sq*ans[2]);
    ezv = conj(k1^2*(answer(2) + k2^2*answer(5))); % *ezv=conj(ck1sq*(ans[1]+ck2sq*ans[4]));
    erh = conj(k2^2*(answer(1) + answer(6))); % *erh=conj(ck2sq*(ans[0]+ans[5]));
    eph = -conj(k2^2*(answer(4) + answer(6))); % *eph=-conj(ck2sq*(ans[3]+ans[5]));
  else
    % unconjugated
    erv = k1^2*answer(3); 
    ezv = k1^2*(answer(2) + k2^2*answer(5)); 
    erh = k2^2*(answer(1) + answer(6)); 
    eph = -k2^2*(answer(4) + answer(6)); 
  end
end