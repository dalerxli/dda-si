% Reference:
% Roland Schmehl, Brent M. Nebeker, and E. Dan Hirleman
% "Discrete-dipole approximation for scattering by features on surfaces 
% by means of a two-dimensional fast Fourier transform technique" 
% J. Opt. Soc. Am. A 14, 3026-3036 (1997) 

function Rjk = reflection_Rjk(k1,k2,r_j,r_k,S)
% k1 = wave number in bottom medium (e.g. substrate)
% k2 = wave number in top medium (e.g. air/vacuum)
% r_j = receiving dipole coordinate [x y z]
% r_k = radiating dipole coordinate [x y z]
% S = precalculated Sommerfeld essential integrals

k0 = 2*pi;

% (A9d)
rI_k2j = [r_j(1)-r_k(1) r_j(2)-r_k(2) r_j(3)+r_k(3)]; 
rIjk = norm(rI_k2j);

% x,y,z components vectors (A9a)
rhat_x = rI_k2j(1)/rIjk; 
rhat_y = rI_k2j(2)/rIjk;
rhat_z = rI_k2j(3)/rIjk;

% scalars (A9b) & (A9c)
beta = (1 - 1*(k0*rIjk)^-2 + i*(k0*rIjk)^-1);
gamma = -(1 - 3*(k0*rIjk)^-2 + i*3*(k0*rIjk)^-1);

zph = r_j(3)+r_k(3);
rho = sqrt((r_j(1) - r_k(1))^2 + (r_j(2) - r_k(2))^2);

% assign precalculated Sommerfeld essential integrals
IV_rho = S(1);
IV_z = S(2);
IH_rho = S(3);
IH_phi = S(4);

S11 = rhat_x^2*IH_rho - rhat_y^2*IH_phi;
S12 = rhat_x*rhat_y*(IH_rho + IH_phi);
S13 = rhat_x*IV_rho;
S21 = rhat_x*rhat_y*(IH_rho + IH_phi);
S22 = rhat_y^2*IH_rho - rhat_x^2*IH_phi;
S23 = rhat_y*IV_rho;
S31 = -rhat_x*IV_rho;
S32 = -rhat_y*IV_rho;
S33 = IV_z;

Sjk = [S11 S12 S13; S21 S22 S23; S31 S32 S33];

G11 = -(beta + gamma*rhat_x^2);
G12 = -gamma*rhat_x*rhat_y;
G13 = gamma*rhat_x*rhat_z;
G21 = -gamma*rhat_y*rhat_x;
G22 = -(beta + gamma*rhat_y^2);
G23 = gamma*rhat_y*rhat_z;
G31 = -gamma*rhat_z*rhat_x;
G32 = -gamma*rhat_z*rhat_y;
G33 = beta + gamma*rhat_z^2;

Gjk = [G11 G12 G13; G21 G22 G23; G31 G32 G33];
% to be consistent with the Draine and Flatau interraction matrix 
% formulation we omit the (4*pi*ep)^-1 factor
% (A8)

Rjk = -(Sjk + k0^2*(k1^2-k2^2)/(k1^2+k2^2)*exp(i*k0*rIjk)/rIjk*Gjk);% as per Schmehl's thesis 

% The required k0^2 factor was reported by Dr. Andrey Evlyukhin, Laser Zentrum Hannover e.V.
% as per Schmehl's thesis (2.41). In the previous version, 
% Rjk = -(Sjk + (k1^2-k2^2)/(k1^2+k2^2)*exp(i*k0*rIjk)/rIjk*Gjk); % as per Schmehl (A8)