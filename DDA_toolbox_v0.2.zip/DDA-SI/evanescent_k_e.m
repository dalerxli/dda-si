% Calculates the wave vector of the evanescent field above a flat substrate
% whose interface on the x-y plane at z=0 (z being the vertical axis).
% The incident plane wave is internally reflected and its wave vectors are
% on the y-z plane, i.e., x=0

% Based on:
% Tojo, S. & Hasuo, M.,
% "Oscillator-strength enhancement of electric-dipole-forbidden transitions 
% in evanescent light at total reflection", 
% Physical Review A, 2005, 21, 012508

% However, the incident plane here is y-z instead of x-z.

function [k2,ep,es]=evanescent_k_e(theta_1,n1,n2)

% theta_1 : incident angle
% n1 : substrate reflective index
% n2 : reflective index of the medium above the substrate, e.g., air 

% k2 : wave vector above the substrate
% ep : TM polarisation vector
% es : TE polarisation vector

k0 = 2*pi; % wave number in vacuum
theta_c = asin(n2/n1); % critical angle
sin_theta_2 = (n1/n2)*sin(theta_1);
theta_2 = asin(sin_theta_2)

% This is correct regardless of incident angle. Has round-off error.
% Use this for the general case
%k2 = [0 n2*k0*sin_theta_2 n2*k0*cos(theta_2)];

% This is only correct beyond the critical angle; 
% the sign for k_z is opposite otherwise. However, no round-off error.
if isreal(theta_2)
  k2 = [0 n1*k0*sin(theta_1) i*k0*sqrt((n1*sin(theta_1))^2 - n2^2)];
else  
  k2 = [0 n1*k0*sin(theta_1) -i*k0*sqrt((n1*sin(theta_1))^2 - n2^2)];
end
  
ep = [0 i*sqrt((n1/n2*sin(theta_1))^2 - 1) n1/n2*sin(theta_1)];
es = [1 0 0];