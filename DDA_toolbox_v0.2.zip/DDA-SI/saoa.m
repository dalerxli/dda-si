% saoa computes the integrand for each of the 6 sommerfeld */
% integrals for source and observer above ground */
%void saoa( double t, complex double *ans)
function answer = saoa(t,zph,rho,k1,k2,a,b,jh)
%   double xlr, sign;
%   static complex double xl, dxl, cgam1, cgam2, b0, b0p, com, dgam, den1, den2;
tsmag = 100*k1*conj(k1);
cksm = k2^2/(k1^2 + k2^2); % cksm=ck2sq/(ck1sq+ck2sq);
ct1 = .5*(k1^2 - k2^2); %ct1=.5*(ck1sq-ck2sq);
% erv=ck1sq*ck1sq;
% ezv=ck2sq*ck2sq;
% ct2=.125*(erv-ezv);
ct2 = .125*(k1^4 - k2^4);
% erv *= ck1sq;
% ezv *= ck2sq;
% ct3=.0625*(erv-ezv);
ct3 = .0625*(k1^6 - k2^6);

[xl,dxl] = lambda(t,a,b); % lambda(t, &xl, &dxl);

if (jh == 0)
  % bessel function form
  [b0,b0p] = bessel0(xl*rho); % bessel(xl*rho, &b0, &b0p);
  b0 = b0*2; % b0  *=2.;
  b0p = b0p*2; % b0p *=2.;
  cgam1 = sqrt(xl^2 - k1^2); % cgam1=csqrt(xl*xl-ck1sq);
  cgam2 = sqrt(xl^2 - k2^2); % cgam2=csqrt(xl*xl-ck2sq);
  if real(cgam1) == 0 %if(creal(cgam1) == 0.);
    cgam1 = abs(imag(cgam1))*i; % cgam1=cmplx(0.,-fabs(cimag(cgam1)));
  end
  if real(cgam2) == 0 % if(creal(cgam2) == 0.)
    cgam2 = abs(imag(cgam2))*i; % cgam2=cmplx(0.,-fabs(cimag(cgam2)));
  end
else
  % hankel function form
  [b0,b0p] = hankel0(xl*rho); % hankel(xl*rho, &b0, &b0p);
  com = xl - k1; % com=xl-ck1;
  cgam1 = sqrt(xl + k1)*sqrt(com); % cgam1=csqrt(xl+ck1)*csqrt(com);
  if (real(com) < 0) && (imag(com) >= 0) % if(creal(com) < 0. && cimag(com) >= 0.)
    cgam1 = -cgam1;
  end
  com = xl - k2; % com=xl-ck2;
  cgam2 = sqrt(xl + k2)*sqrt(com); %cgam2=csqrt(xl+ck2)*csqrt(com);
  if (real(com) < 0) && (imag(com) >= 0) %if(creal(com) < 0. && cimag(com) >= 0.)
    cgam2 = -cgam2;
  end
end

xlr = xl*conj(xl);
if (xlr >= tsmag)
  if (imag(xl) >= 0)
    xlr = real(xl);
    if (xlr >= k2)
      if (xlr <= real(k1)) %if(xlr <= ck1r)
        dgam = cgam2 - cgam1;
      else
        sign = 1;
        dgam = 1/(xl^2); %dgam=1./(xl*xl);
        dgam = sign*((ct3*dgam + ct2)*dgam + ct1)/xl;
      end
    else
      sign = -1;
      dgam = 1/xl^2; % dgam=1./(xl*xl);
      dgam = sign*((ct3*dgam + ct2)*dgam + ct1)/xl;
    end % /* if(xlr >= ck2) */

    % /* if(cimag(xl) >= 0.) */
  else
    sign = 1;
    dgam = 1/xl^2; % dgam=1./(xl*xl);
    dgam = sign*((ct3*dgam + ct2)*dgam + ct1)/xl;
  end

  % /* if(xlr < tsmag) */
else
  dgam = cgam2 - cgam1;
end

den2 = cksm*dgam/(cgam2*(k1^2*cgam2 + k2^2*cgam1)); % den2=cksm*dgam/(cgam2*(ck1sq*cgam2+ck2sq*cgam1));
den1 = 1/(cgam1 + cgam2) - cksm/cgam2;
com = dxl*xl*exp(-cgam2*zph);
answer(6) = com*b0*den1/k1; % ans[5] = com*b0*den1/ck1;
com = com * den2; %com *= den2;

if(rho ~= 0) % if(rho != 0.)
  b0p = b0p/rho;
  answer(1) = -com*xl*(b0p + b0*xl); % ans[0]=-com*xl*(b0p+b0*xl);
  answer(4) = com*xl*b0p; % ans[3]=com*xl*b0p;
else
  answer(1) = -com*xl*xl*.5; % ans[0]=-com*xl*xl*.5;
  answer(4) = answer(1); % ans[3]=ans[0];
end

answer(2) = com*cgam2*cgam2*b0; % ans[1]=com*cgam2*cgam2*b0;
answer(3) = -answer(4)*cgam2*rho; % ans[2]=-ans[3]*cgam2*rho;
answer(5) = com*b0; % ans[4]=com*b0;