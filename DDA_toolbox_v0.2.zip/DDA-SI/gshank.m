% gshank integrates the 6 sommerfeld integrals from start to 
% infinity (until convergence) in lambda.  at the break point, bk, 
% the step increment may be changed from dela to delb.  shank's 
% algorithm to accelerate convergence of a slowly converging series 
% is used 
% void gshank( complex double start, complex double dela, complex double *sum,
%     int nans, complex double *seed, int ibk, complex double bk, complex double delb )
function [suminc] = gshank(start,dela,suminc,nans,seed,ibk,bk,delb,zph,rho,k1,k2,jh)
% start = A_0
% dela = delta before break point
% suminc = increment of integral
% nans = number of functions
% seed = S_0
% ibk = flag if path contains a break point (1 or 0)
% bk = break point (d*) in the path
% delb = delta after break point
% jh = flag 1 or 0, respectively for Bessel or Hankel function forms    

% complex double q1[6][20], q2[6][20], ans1[6], ans2[6];
q1 = zeros(6,20);
q2 = zeros(6,20);
ans1 = zeros(6,1);

% constants
MAXH = 20;
CRIT = 1E-4;

rbk = real(bk);
del = dela;
if (ibk == 0)
  ibx=1;
else
  ibx=0;
end

% for( i = 0; i < nans; i++ )
%   ans2[i]=seed[i];
ans2 = seed;

b = start;
% for( intx = 1; intx <= MAXH; intx++ )
for intx = 1:MAXH
  inx = intx; % inx=intx-1;
  a = b;
  b = b + del; % b += del;

  if ((ibx == 0) && (real(b) >= rbk))
    % hit break point.  reset seed and start over. 
    ibx = 1;
    b = bk;
    del = delb;
    suminc = rom1(nans,2,zph,rho,k1,k2,a,b,jh); % rom1(nans,sum,2);
    if (ibx ~= 2)
% 	  for( i = 0; i < nans; i++ )
% 	    ans2[i] += sum[i];
      ans2 = ans2 + suminc;
	    intx = 0;
      continue
    end

%   for( i = 0; i < nans; i++ )
%     ans2[i]=ans1[i]+sum[i];
    ans2 = ans1 + suminc;  
    intx = 0;
    continue
  end %  } /* if( (ibx == 0) && (creal(b) >= rbk) ) */

  suminc = rom1(nans,2,zph,rho,k1,k2,a,b,jh); % rom1(nans,sum,2);
% for( i = 0; i < nans; i++ )
%   ans1[i] = ans2[i]+sum[i];
  ans1 = ans2 + suminc;
  
  a = b;
  b = b + del; % b += del;

% if( (ibx == 0) && (creal(b) >= rbk) )
  if ((ibx == 0) && (real(b) >= rbk))
    % hit break point.  reset seed and start over. 
    ibx = 2;
    b = bk;
    del = delb;
    suminc = rom1(nans,2,zph,rho,k1,k2,a,b,jh); % rom1(nans,sum,2);
    if (ibx ~= 2)
%   	for( i = 0; i < nans; i++ )
%   	  ans2[i] += sum[i];
      ans2 = ans2 + suminc;
	    intx = 0;
      continue
    end

%   for( i = 0; i < nans; i++ )
%   	ans2[i] = ans1[i]+sum[i];
    ans2 = ans1 + suminc;
    intx = 0;
    continue
  end % } /* if( (ibx == 0) && (creal(b) >= rbk) ) */

  suminc = rom1(nans,2,zph,rho,k1,k2,a,b,jh);  % rom1(nans,sum,2);
  
% for( i = 0; i < nans; i++ )
%   ans2[i]=ans1[i]+sum[i];
  ans2 = ans1 + suminc;

  den=0;
  for j = 1:nans  % for( i = 0; i < nans; i++ )
    as1 = ans1(j); % as1=ans1[i];
    as2 = ans2(j); % as2=ans2[i];

    if (intx >= 2)
 	    % for( j = 1; j < intx; j++ )
      for k = 1:intx-1
        km = k; % jm=j-1;
	      aa = q2(j,km); % aa=q2[i][jm];
	      a1 = q1(j,km) + as1 - 2*aa; % a1=q1[i][jm]+as1-2.*aa;

	      %if( (creal(a1) != 0.) || (cimag(a1) != 0.) )
	      if ((real(a1) ~= 0.) || (imag(a1) ~= 0.)) 
	        a2 = aa - q1(j,km); % a2=aa-q1[i][jm];
	        a1 = q1(j,km) - a2*a2/a1; % a1=q1[i][jm]-a2*a2/a1;
        else
	        a1 = q1(j,km); % a1=q1[i][jm];
        end

	      a2 = aa + as2 - 2*as1;
	      %if( (creal(a2) != 0.) || (cimag(a2) != 0.) )
        if ((real(a2) ~= 0) || (imag(a2) ~= 0))
	        a2 = aa - (as1 - aa)*(as1 - aa)/a2;
        else
	        a2 = aa;
        end
        
	      q1(j,km) = as1; % q1[i][jm]=as1;
	      q2(j,km) = as2; % q2[i][jm]=as2;
	      as1 = a1;
	      as2 = a2;
      end % } /* for( j = 1; i < intx; i++ ) */
    end % } /* if(intx >= 2) */

    q1(j,intx) = as1; % q1[i][intx-1]=as1;
    q2(j,intx) = as2; % q2[i][intx-1]=as2;
    
    % amg=fabs(creal(as2))+fabs(cimag(as2));
    amg = abs(real(as2)) + abs(imag(as2));
    if (amg > den)
	    den = amg;
    end
  end % } /* for( i = 0; i < nans; i++ ) */

  denm = 1E-3*den*CRIT; % denm=1.e-3*den*CRIT;
  km = intx - 3; % jm=intx-3;
  if (km < 1)
    km = 1;
  end

  %for( j = jm-1; j < intx; j++ )
  for k = km:intx
    brk = 0; % brk = FALSE;
    %for (i = 0; i < nans; i++ )
    for j = 1:nans
	    a1 = q2(j,k); %a1=q2[i][j];
	    den = (abs(real(a1)) + abs(imag(a1)))*CRIT; %den=(fabs(creal(a1))+fabs(cimag(a1)))*CRIT;
	    if (den < denm)
	      den = denm;
      end
	    a1 = q1(j,k) - a1; % a1=q1[i][j]-a1;
	    amg = abs(real(a1) + abs(imag(a1)));
	    if (amg > den)
	      brk = 1; % brk = TRUE;
	      break
      end
    end % } /* for( i = 0; i < nans; i++ ) */

    if brk 
      break
    end
  end % } /* for( j = jm-1; j < intx; j++ ) */

  if ~brk % if( ! brk )
%     for( i = 0; i < nans; i++ )
% 	    sum[i]=.5*(q1[i][inx]+q2[i][inx]);
    suminc = .5*(q1(:,inx) + q2(:,inx));  
    return
  end
     
end % } /* for( intx = 1; intx <= maxh; intx++ ) */

%   /* No convergence */
%   abort_on_error(-6);
% TODO: handle error