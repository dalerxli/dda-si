% Fresnel amplitude reflection coefficients 

function [R_TE,R_TM] = Fresnel_coeff_n(n_r,theta)
% n_r : relative refractive index bottom substrate medium
% theta : incident angle (from surface normal)

R_TM = (sqrt(1 - (sin(theta)/n_r)^2) - n_r*cos(theta))/...
       (sqrt(1 - (sin(theta)/n_r)^2) + n_r*cos(theta));
      
R_TE = (cos(theta) - n_r*sqrt(1 - (sin(theta)/n_r)^2))/...
       (cos(theta) + n_r*sqrt(1 - (sin(theta)/n_r)^2));
      