% Draine & Flatau

function E = E_sca_SI(k,r,P,det_r,theta,phi,n1)
% k: wave vector
% r: dipole coordinates (N x 3 matrix)
% P: polarizations (vector of length 3N; Px1,Py1,Pz1 ... PxN,PyN,PzN)
% det_r, theta, phi: evaluation points in spherical coordinates
% n1: refractive index of substrate

% Note: coordinates are relative to origin

[N,cols] = size(r);

[rows,cols] = size(theta);
if cols > rows
  theta = reshape(theta,cols,rows);
end
[rows,cols] = size(phi);
if cols > rows
  phi = reshape(phi,cols,rows);
end
[rows,cols] = size(det_r);
if cols > rows
  det_r = reshape(det_r,cols,rows);
end

%pts = length(r_unit);
r_sp = [det_r theta phi];
[pts,cols] = size(r_sp);
r_unit = ones(pts,1);
er_sp = [r_unit theta phi];
e1_sp = [r_unit theta+sign(theta)*pi/2 phi];

r_E = rtp2xyz(er_sp);
r_E1 = rtp2xyz(e1_sp);
er = zeros(pts,3);
e1 = zeros(pts,3);
e2 = zeros(pts,3);
% r_E2 = rtp2xyz(er_sp);
% er2 = zeros(pts,3);
for j = 1:pts
  er(j,:) = r_E(j,:)/norm(r_E(j,:));
  e1(j,:) = r_E1(j,:)/norm(r_E1(j,:));
  e2(j,:) = cross(er(j,:),e1(j,:));
end

E = zeros(pts,3);

for pt = 1:pts
  erp = er(pt,:); %e_r
  e1p = e1(pt,:); %e_theta
  e2p = e2(pt,:); %e_phi
  k_sca = k*erp;
  k_Isca = [k_sca(1) k_sca(2) -k_sca(3)];
  
  % This is the modification was made Mitchell Short, University of Utah,
  % to account for the Fresnel coefficient at each angle of dipole 
  % as opposed to single incident angle.
  ref_angle=abs((-pi/2)+(pt-1)*pi/length(theta));
  [refl_TE,refl_TM] = Fresnel_coeff_n(n1,abs(ref_angle));

  %rp = norm(r_E(pt,:)); 
  rp = det_r(pt);
  for j = 1:N
    Pj = P(3*(j-1)+1:3*(j-1)+3);
    rj = r(j,:);
    rIj = [rj(1) rj(2) -rj(3)];
    E(pt,:) = E(pt,:) + ...
      exp(-i*dot(k_sca,rj))*(dot(Pj,e1p)*e1p + dot(Pj,e2p)*e2p) + ...
      exp(-i*dot(k_Isca,rj))*(refl_TM*dot(Pj,e1p)*e1p + refl_TE*dot(Pj,e2p)*e2p);
%     E(pt,:) = E(pt,:) + ...
%       exp(-i*k_sca.*rj).*(dot(Pj,e1p)*e1p + dot(Pj,e2p)*e2p) + ...
%       exp(-i*k_sca.*rIj).*(refl_TM*dot(Pj,e1p)*e1p + refl_TE*dot(Pj,e2p)*e2p);

    % dot(k_sca,rIj) and dot(k_Isca,rj) are equal. 
    % Refer to Schmel's thesis (2.58) 
  end
  E(pt,:) = E(pt,:)*k^2*exp(i*k*rp)./(4*pi*rp);
end

