% void lambda( double t, complex double *xlam, complex double *dxlam )
% {
%   *dxlam=b-a;
%   *xlam=a+*dxlam*t;
%   return;
% }
function [xlam,dxlam] = lambda(t, a, b)
% a = start of integration interval
% b = ed of integration interval

dxlam = b - a;
xlam = a + dxlam*t;
