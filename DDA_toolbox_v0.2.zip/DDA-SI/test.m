% void test( double f1r, double f2r, double *tr,
%     double f1i, double f2i, double *ti, double dmin )
function [tr,ti] = test(f1r,f2r,f1i,f2i,dmin)

den= abs(f2r);
tr= abs(f2i);

if (den < tr)
  den = tr;
end

if (den < dmin)
  den = dmin;
end

if (den < 1E-37)
  tr=0;
  ti=0;
  return
end

tr= abs((f1r - f2r)/den);
ti= abs((f1i - f2i)/den);

return