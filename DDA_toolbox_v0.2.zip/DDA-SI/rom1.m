% rom1 integrates the 6 sommerfeld integrals from a to b in lambda. 
% the method of variable interval width romberg integration is used. 
% void rom1( int n, complex double *sum, int nx )
function suminc = rom1(n,nx,zph,rho,k1,k2,a,b,jh)
% n = number of functions?
% nx = ?
% static double z, ze, s, ep, zend, dz=0., dzot=0., tr, ti;
% static complex double t00, t11, t02;
% static complex double g1[6], g2[6], g3[6], g4[6], g5[6], t01[6], t10[6], t20[6];
dz = 0;
dzot = 0;
t01 = zeros(n,1);
t10 = zeros(n,1);
t20 = zeros(n,1);

% constants
NM = 131072;
CRIT = 1E-4;
NTS = 4;

lstep = 0;
z = 0;
ze = 1;
s = 1;
ep = s/(1E4*NM); % ep=s/(1.e4*NM);
zend=ze-ep;
%   for( i = 0; i < n; i++ )
%     sum[i]=CPLX_00;
suminc = zeros(n,1);
ns = nx;
nt = 0;
g1 = saoa(z,zph,rho,k1,k2,a,b,jh); % saoa(z,g1);

jump = 0; % jump = FALSE;
while true % while( TRUE )
  if ~jump % if( ! jump )
    dz = s/ns;    
    if ((z+dz) > ze)
	    dz = ze - z;
	    if (dz <= ep)
	      return
      end  
    end 

    dzot = dz * .5;
    g3 = saoa(z + dzot,zph,rho,k1,k2,a,b,jh); %saoa(z+dzot,g3);
    g5 = saoa(z + dz,zph,rho,k1,k2,a,b,jh); %saoa(z+dz,g5);
  end % } /* if( ! jump ) */

  nogo = 0; % nogo=FALSE;
%   for( i = 0; i < n; i++ )
%   {
%     t00=(g1[i]+g5[i])*dzot;
%     t01[i]=(t00+dz*g3[i])*.5;
%     t10[i]=(4.*t01[i]-t00)/3.;
% 
%     /* test convergence of 3 point romberg result */
%     test( creal(t01[i]), creal(t10[i]), &tr, cimag(t01[i]), cimag(t10[i]), &ti, 0. );
%     if( (tr > CRIT) || (ti > CRIT) )
% 	    nogo = TRUE;
%   }
  for j = 1:n
    t00 = (g1(j) + g5(j))*dzot;
    t01(j) = (t00 + dz*g3(j))*.5;
    t10(j) = (4*t01(j) - t00)/3;

    % test convergence of 3 point romberg result
    %test( creal(t01[i]), creal(t10[i]), &tr, cimag(t01[i]), cimag(t10[i]), &ti, 0. );
    [tr,ti] = test(real(t01(j)),real(t10(j)),imag(t01(j)),imag(t10(j)),0);
    if ( (tr > CRIT) || (ti > CRIT) )
	    nogo = 0; % nogo=TRUE;
    end
  end

  if ~nogo % if( ! nogo )
%     for( i = 0; i < n; i++ )
%     	sum[i] += t10[i];
    suminc = suminc + t10;

    nt = nt + 2; % nt += 2;
    z = z + dz; % z += dz;
    if (z > zend)
	    return
    end

%     for( i = 0; i < n; i++ )
% 	    g1[i]=g5[i];
    g1 = g5;

    if ((nt >= NTS) && (ns > nx))
    	ns = ns/2;
	    nt = 1;
    end

    jump = 0; % jump = FALSE;
    continue
  end %% } /* if( ! nogo ) */

  g2 = saoa(z + dz*.25,zph,rho,k1,k2,a,b,jh); % saoa(z+dz*.25,g2);
  g4 = saoa(z + dz*.75,zph,rho,k1,k2,a,b,jh); % saoa(z+dz*.75,g4);
  nogo = 0; % nogo=FALSE;
  
% for( i = 0; i < n; i++ )
% {
%   t02=(t01[i]+dzot*(g2[i]+g4[i]))*.5;
%   t11=(4.*t02-t01[i])/3.;
%   t20[i]=(16.*t11-t10[i])/15.;
% 
%   /* test convergence of 5 point romberg result */
%   test( creal(t11), creal(t20[i]), &tr, cimag(t11), cimag(t20[i]), &ti, 0. );
%   if( (tr > CRIT) || (ti > CRIT) )
%   nogo = TRUE;
% }
  for j = 1:n
    t02 = (t01(j) + dzot*(g2(j) + g4(j)))*.5;
    t11 = (4*t02 - t01(j))/3;
    t20(i) = (16*t11 - t10(i))/15;

    % test convergence of 5 point romberg result
    [tr,ti] = test(real(t11),real(t20(j)),imag(t11),imag(t20(i)),0);
    if ((tr > CRIT) || (ti > CRIT))
      nogo = 1; % nogo = TRUE;
    end
  end

  if ~nogo % if( ! nogo )
%     for( i = 0; i < n; i++ )
% 	    sum[i] += t20[i];
    suminc = suminc + t20;
    
    nt = nt + 1; % nt++;
    z = z + dz; % z += dz;
    if (z > zend)
	    return
    end

%     for( i = 0; i < n; i++ )
% 	    g1[i]=g5[i];
    g1 = g5;

    if ((nt >= NTS) && (ns > nx))
    	ns = ns/2;
	    nt = 1;
    end

    jump = 0; % jump = FALSE;
    continue
  end % } /* if( ! nogo ) */

  nt = 0;
  if (ns < NM)
    ns = ns * 2; % ns *= 2;
    dz = s/ns;
    dzot = dz*.5;

%     for( i = 0; i < n; i++ )
%     {
% 	    g5[i]=g3[i];
% 	    g3[i]=g2[i];
%     }
    g5 = g3;
    g3 = g2;

    jump = 1; % jump = TRUE;
    continue
  end % } /* if(ns < nm) */

  if ~lstep %  if( ! lstep )
    lstep = 1; % lstep = TRUE;
    [t00,t11] = lambda(z,a,b); % lambda( z, &t00, &t11 );
  end

%   for( i = 0; i < n; i++ )
%     sum[i] += t20[i];
  suminc = suminc + t20;
  
  nt = nt + 1; % nt++;
  z = z + dz; % z += dz;
  if (z > zend)
    return
  end
  
%   for( i = 0; i < n; i++ )
%     g1[i]=g5[i];
  g1 = g5;

  if ((nt >= NTS) && (ns > nx))
    ns = ns/2; % ns /= 2;
    nt=1;
  end

  jump = 0; % jump = FALSE;
end %%  } /* while( TRUE ) */
