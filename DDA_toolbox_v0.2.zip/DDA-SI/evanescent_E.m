% Calculates the evanescent field amplitudes above a flat substrate
% whose interface on the x-y plane at z=0 (z being the vertical axis).
% The incident plane wave is internally reflected and its wave vectors are
% on the y-z plane, i.e., x=0

% Based on:
% Tojo, S. & Hasuo, M.,
% "Oscillator-strength enhancement of electric-dipole-forbidden transitions 
% in evanescent light at total reflection", 
% Physical Review A, 2005, 21, 012508

% However, the incident plane here is y-z instead of x-z.
% The y-component of the incident and transmitted wave vector should be +ve 

function [k2,E2s,E2p]=evanescent_E(E1s,E1p,theta_1,n1,n2)

% E1p : TM E-field amplitude
% E1s : TE E-field amplitude
% theta_1 : incident angle
% n1 : substrate reflective index
% n2 : reflective index of the medium above the substrate, e.g., air 

% k2 : wave vector above the substrate
% E2p : TM E-field vector
% E2s : TE E-field vector
[k2,ep,es]=evanescent_k_e(theta_1,n1,n2);

T2s = (2*n1*cos(theta_1))/(n1*cos(theta_1) + sqrt(n2^2 - (n1*sin(theta_1))^2))*E1s;
T2p = (2*n1*cos(theta_1))/(n2*cos(theta_1) + (n1/n2)*sqrt(n2^2 - (n1*sin(theta_1))^2))*E1p;

E2s = es*T2s;
E2p = ep*T2p;