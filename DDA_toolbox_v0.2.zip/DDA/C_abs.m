function C = C_abs(k, E0, Ei, P, alph)

%invalph = 1./alph;
%C = 4*pi*k/abs(sum(E0.^2))*(-imag(dot(P,invalph.*P)) - 2/3*k^3*dot(P,P));

C = 4*pi*k/sum(abs(E0.^2))*(-imag(dot(P,P./alph)) - 2/3*k^3*dot(P,P));

% just checking; got same result as above
% C1 = 0;
% N = length(P);
% for j = 1:N
%   C1 = C1 + (-imag(dot(P(j),P(j)/alph(j))) - 2/3*k^3*abs(P(j)^2));
% end  
% 
% C1 = 4*pi*k/abs(sum(E0.^2))*C1