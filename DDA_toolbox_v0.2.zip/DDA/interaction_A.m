% Vectorized method for formulating the global interaction matrix A.
% Much faster than using interaction_A_glob.m.
function calc_A_glob(k,r,alph,blockdiag)
global A

if nargin < 4
  blockdiag = 1;
end
  
[N,dummy] = size(r);
A = single(zeros(3*N,3*N));
%subj = 0;
for j=1:N
  %subj = subj + 1;
  crow = 3*(j-1);
  Aj = calc_Aj(k,r,alph,j,blockdiag);
  A(crow+1:crow+3,:) = Aj;
end
