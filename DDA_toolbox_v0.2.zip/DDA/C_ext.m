function C = C_ext(k, E0, Ei, P)
% WARNING - this version is designed for Cartesian coordinates only

C = 4*pi*k/sum(abs(E0.^2))*imag(dot(Ei,P));
