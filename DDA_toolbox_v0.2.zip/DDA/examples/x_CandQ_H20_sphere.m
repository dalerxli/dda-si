clear all
global A Ei alph k r

iterative = 1; % 0: none, 1: gmres, 2: minres, 3: qmr

E0 = [1 1 0]; 
%m1 = 1.33; % relative refractive index of water
m1 = 1.33 + .1i;   % imag. component to demonstrate absorption
k = 2*pi;          % wave number
d = 1/(abs(m1)*k); % lattice spacing

% number of dipoles in the approximate sphere; more is required as the
% radius increases
%nrange = [8 32 136 280 552 912 1472 2176 3112 4224 5616 7208 9328 11536];
nrange = [8 32 136 280 552 912 1472];

% the corresponding effective radii of the spheres
arange = (3*nrange/(4*pi)).^(1/3) * d; 

Cscat = zeros(1,length(nrange));

ix = 0; % index, counter
for N = nrange
  ix = ix+1;
  m = m1*ones(N,1);
  kvec = [0 0 k];
  rfile = ['../../shape/sphere_' int2str(nrange(ix)) '.txt'];
  S=dlmread(rfile);
  r = d*[S(:,1) S(:,2) S(:,3)];
  Ei = E_inc(E0, kvec, r);
  alph=polarizability_LDR(d,m,kvec,E0);
  tic
  % Here, we use the global version of the interaction matrix to save
  % memory. Remember to declare 'global A' as above
  interaction_A(k, r, alph);
  t_A = toc
  tic
  switch iterative
    case 0
      P = A\Ei;
    case 1
      P = gmres(A, Ei);
    case 2
      P = minres(A,Ei);
    case 3
      P = qmr(A,Ei);
  end
  t_P = toc
%   switch iterative
%     case 0
%       P = feval(@interaction_A)\Ei;
%     case 1
%       P = gmres(feval(@interaction_A), Ei);
%     case 2
%       P = minres(feval(@interaction_A),Ei);
%     case 3
%       P = qmr(feval(@interaction_A),Ei);
%   end  

  Cext(ix) = C_ext(k, E0, Ei, P);
  Cabs(ix) = C_abs(k, E0, Ei, P, alph);
  Cscat(ix) = Cext(ix) - Cabs(ix);
end
% the interaction matrix may take up a lot of memory so it can be cleared
% when no longer required
clear A  

% Here, we plot the efficiencies Q instead of the cross sections C
% Q = C/(pi*r^2) 
figure(2)
clf
hold on
plot(k*arange,Cext./(pi*arange.^2),'*')
plot(k*arange,Cabs./(pi*arange.^2),'x')
plot(k*arange,Cscat./(pi*arange.^2),'o')
legend('Q_{ext}','Q_{abs}','Q_{scat}',0,0)
ylabel('Q')
xlabel('2\pia/\lambda') % size parameter
title(['m = ' num2str(m1)])
hold off
