% phase function demo for a water sphere

clear all
global A

E0 = [1 0 0]; % x-polarization
m1 = 1.33;
shapepath = '../../shape/';
rfile = [shapepath 'sphere_552.txt'];
S=dlmread(rfile);
N = length(S(:,1))

k = 2*pi; % wave number
d = 1/(abs(m1)*k);
a_eff = (3*N/(4*pi))^(1/3)*1/(k*abs(m1));
r = d*[S(:,1) S(:,2) S(:,3)];
m = m1*ones(N,1);
kvec = [0 0 k]; % propagating in +z direction
Ei = E_inc(E0,kvec,r);
alph = polarizability_LDR(d,m,k);
interaction_A(k,r,alph);
P = gmres(A,Ei);

range = linspace(0,pi,100);

Esca_S = zeros(1,length(range));
Esca_P = zeros(1,length(range));
Einc_S = zeros(1,length(range));
Einc_P = zeros(1,length(range));

ix = 0;
for theta = range
  ix = ix+1;
  
  phi = 90; % perpendicular to x-z plane
  r_E = zeros(1,3); % evaluation point
  [r_E(1) r_E(2) r_E(3)] = rtp2xyz(100, theta, phi);
  E = E_sca_FF(k,r,P,r_E); 
  Esca_S(ix) = norm(E);
  kr = dot([k k k],r_E,2);
  expikr = exp(i.*kr);
  E1 = [E0(1)*expikr E0(2)*expikr E0(3)*expikr];
  Einc_S(ix) = norm(E1);

  
  phi = 0; % parallel to x-z plane
  r_E = zeros(1,3);
  [r_E(1) r_E(2) r_E(3)] = rtp2xyz(100, theta, phi);
  E = E_sca_FF(k,r,P,r_E); 
  Esca_P(ix) = norm(E);
  kr = dot([k k k],r_E,2);
  expikr = exp(i.*kr);
  E1 = [E0(1)*expikr E0(2)*expikr E0(3)*expikr];
  Einc_P(ix) = norm(E1);
end

figure(1)
clf
ph=semilogy(range*180/pi,Esca_P.^2./Einc_P.^2,'--',range*180/pi,Esca_S.^2./Einc_S.^2)
%set(ph,'LineWidth',2)
xlim([0 180])
ylabel('log |E_{sca}|^2','FontSize',14)
xlabel('phase angle','FontSize',14)
title(['ka = ' num2str(k*a_eff) ', m = ' num2str(m1) ', N = ' int2str(N)],'FontSize',14)
legend('parallel','perpendicular')
set(gca,'FontSize',14)
%print -deps PF_sphere.eps

