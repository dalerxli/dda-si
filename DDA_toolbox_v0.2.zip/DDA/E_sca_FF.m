% Draine & Flatau

function E = E_sca_FF(k,r,P,r_E)
% k: wave number
% r: dipole coordinates (N x 3 matrix)
% P: polarizations (vector of length 3N; Px1,Py1,Pz1 ... PxN,PyN,PzN)
% r_E: coord for the point at which to calculate the far field
% Note: coordinates are relative to origin

[N,cols] = size(r);

E = 0;
r_norm = norm(r_E);
r_hat = r_E/r_norm; 

for j = 1:N
  E = E + exp(-i*k*dot(r_hat,r(j,:)))*(r_hat'*r_hat - eye(3))*P(3*(j-1)+1:3*(j-1)+3);
end  

E = E*k^2*exp(i*k*r_norm)/r_norm;