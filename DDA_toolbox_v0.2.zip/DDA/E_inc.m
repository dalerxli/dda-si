% E_inc.m
% Incident field
function Ei = E_inc(E0,kvec,r)

% E0: field amplitude [Ex Ey Ez]
% kvec: wave vector, 2*pi in wavelength units 
% r: N x 3 matrix, for x_j, y_j, z_j coordinates
% Following Smith & Stokes (2006), the result, E will have 
% N: number of dipoles
% j = 1..N

% E_inc_j = E_0 exp(ik.r_j - iwt)
% Here, we omit the frequency factors exp(iwt) which can
% be calculated outside this function if required. Thus
% E_inc_j = E_0 exp(ik.r_j)

[N,cols] = size(r);
D = ones(N,1);
kr = dot([kvec(1)*D kvec(2)*D kvec(3)*D],r,2);
expikr = exp(i*kr);
E1 = [E0(1)*expikr E0(2)*expikr E0(3)*expikr]; % N x 3

% Ex, Ey & Ez components laid out into a 3N x 1 vector
% Ei = [E1(:,1); E1(:,2); E1(:,3)];

Ei = col3to1(E1);