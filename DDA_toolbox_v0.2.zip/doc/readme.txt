This is a beta release v0.2

Please also download, from the URL below, the Optical Tweezers Toolbox which contains functions required by the DDA-SI toolbox:
http://www.physics.uq.edu.au/people/nieminen/software.html

DDA-SI:
-------

Changes made here are consistent with the version used for the calculation in the publication,
M.R. Short, J.-M. Geffrin, R. Vaillon, H. Tortel, B. Lacroix, and M. Francoeur, "Evanescent wave scattering by particles on a surface: Validation of the discrete dipole approximation with surface interaction against microwave analog experiments," Journal of Quantitative Spectroscopy and Radiative Transfer, in press, 2014. In press, 12/2013.

The modification in E_sca_SI.m was made by Mitchell Short, University of Utah, to account for the Fresnel coefficient at each angle of dipole 
as opposed to single incident angle:

  ref_angle=abs((-pi/2)+(pt-1)*pi/length(theta));
  [refl_TE,refl_TM] = Fresnel_coeff_n(n1,abs(ref_angle));

The required k0^2 factor was reported by Dr. Andrey Evlyukhin, Laser Zentrum Hannover e.V. as per Roland Schmehl's Masters thesis (2.41). 

  Rjk = -(Sjk + k0^2*(k1^2-k2^2)/(k1^2+k2^2)*exp(i*k0*rIjk)/rIjk*Gjk);

The previous version was based on equation (A8) in Schmehl et al., J. Opt. Soc. Am. A 14, 3026-3036 (1997):
  
  Rjk = -(Sjk + (k1^2-k2^2)/(k1^2+k2^2)*exp(i*k0*rIjk)/rIjk*Gjk);



DDA:
----

The interation_A.m function for calculating the interaction matrix A is now vectorized which performs much faster. The variable A has to be declared global. Consequently, interation_A_glob.m is redundant and has been removed. The example scripts that use this function has been changed accordingly.